define([
    'data/js/api/lookup/LookupItem',
    'bop/js/api/entity/DataModelFactory',
    'entity/js/api/PropertyClassification',
    'entity/js/api/PropertyType',
    'entity/js/api/RelationCardinality',
    'bop/js/spi/entity/EntityProvider',
    'com.oracle.iot.bop/js/IoTConstants',
    'com.oracle.iot.bop/js/IoTUtils',
    'com.oracle.iot.bop/js/operation/Formats',
    'com.oracle.iot.bop/js/operation/AssetType'
], function (
        LookupItem,
        DataModelFactory,
        PropertyClassification,
        PropertyType,
        RelationCardinality,
        EntityProvider,
        IoTConstants,
        IoTUtils,
        Formats,
        AssetType
    ) {

    'use strict';

    var IoTEntityProvider = function() {
        AbcsLib.checkThis(this);
        EntityProvider.apply(this, arguments);

        var self = this;

        self._entities = [];
        self.formatTypes = {};
        self.assetTypes = {};

        // init entities
        var applicationBO = self._createApplication();
        self._entities.push(applicationBO);
        self._entities.push(self._createDevice());
        self._entities.push(self._createDeviceModel());
        var messageTypeBO = self._createMessageType();
        self._entities.push(messageTypeBO);
        self._entities.push(self._createMessage(applicationBO, messageTypeBO));
        // create entities for message formats
        self._createFormatBOs(applicationBO, messageTypeBO);

        if (IoTConstants._IOT_AM_ENABLED) {
            self._entities.push(self._createAsset(applicationBO));
            self._createIndividualAssetTypeBOs(applicationBO);
            self._entities.push(self._createFence(applicationBO));
            self._entities.push(self._createPlace(applicationBO));
            self._entities.push(self._createIncident(applicationBO));
        }
    };

    AbcsLib.extend(IoTEntityProvider, EntityProvider);

    IoTEntityProvider._LOGGER = Logger.get('IoT/IoTEntityProvider');

    IoTEntityProvider.prototype.getId = function() {
        return IoTConstants.BOP_ID;
    };

    IoTEntityProvider.prototype.getEntities = function () {
        return this._entities;
    };

    IoTEntityProvider.prototype.initialize = function(appId) {
        var self = this;
        return new Promise(function (fulfil, reject) {
            fulfil();
        });
    };

    IoTEntityProvider.prototype._createFormatBOs = function(applicationBO, messageTypeBO) {
        var self = this;
        var rawFormats = JSON.parse(IoTConstants.IOT_FORMATS);
        Formats.parseResults(rawFormats).forEach(function(oneFormat) {
            if (oneFormat.type === 'DATA') {
                self._entities.push(self._createMessage(applicationBO, messageTypeBO, oneFormat));
            }
        });
    };
    
    IoTEntityProvider.prototype._createIndividualAssetTypeBOs = function(applicationBO) {
        var self = this;
        var rawAssetTypes = JSON.parse(IoTConstants.IOT_ASSET_TYPES);
        IoTUtils.parseAssetTypes(rawAssetTypes).forEach(function(oneAssetType) {
            self._entities.push(self._createAsset(applicationBO, oneAssetType));
        });
    };

    IoTEntityProvider.prototype._createApplication = function() {
        var self = this;
        var id = DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.BASIC
        });
        var name = DataModelFactory.createProperty({
            id: 'name',
            name: 'Name',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });        
        var created = DataModelFactory.createProperty({
            id: 'created',
            name: 'Created',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        });
        var dscrptn = DataModelFactory.createProperty({
            id: 'dscrptn',
            name: 'Description',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var lastModified = DataModelFactory.createProperty({
            id: 'lastModified',
            name: 'Last Modified',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.DATETIME
        });
        var createdAsString = DataModelFactory.createProperty({
            id: 'createdAsString',
            name: 'Created As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var lastModifiedAsString = DataModelFactory.createProperty({
            id: 'lastModifiedAsString',
            name: 'Last Modified As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var type = DataModelFactory.createProperty({
            id: 'type',
            name: 'Type',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var metadata = DataModelFactory.createProperty({
            id: 'metadata',
            name: 'Metadata',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        // TODO: add additional device model properties here

        return DataModelFactory.createEntity({
            id: IoTConstants.APPLICATION_ID,
//            entityProvider: self,
            singularName: 'Application',
            pluralName: 'Applications',
            description: 'Business object representing an application',
            properties: [id, name, created, dscrptn, lastModified, createdAsString,
                         lastModifiedAsString, type, metadata]
        });
    };

    IoTEntityProvider.prototype._createDevice = function() {
        var self = this;
        var id = DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.INTERNAL
        });
        var name = DataModelFactory.createProperty({
            id: 'name',
            name: 'Name',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var manufacturer = DataModelFactory.createProperty({
            id: 'manufacturer',
            name: 'Manufacturer',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var state = DataModelFactory.createProperty({
            id: 'state',
            name: 'State',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        // TODO: add additional device properties here

        return DataModelFactory.createEntity({
            id: IoTConstants.DEVICE_ID,
//            entityProvider: self,
            singularName: 'Device',
            pluralName: 'Devices',
            description: 'Business object representing a device',
            properties: [id, name, manufacturer, state]
        });
    };
    
    IoTEntityProvider.prototype._createDeviceModel = function() {
        var self = this;
        var id = DataModelFactory.createProperty({
            id: 'urn',
            name: 'URN',
            type: PropertyType.KEY,
            classification: PropertyClassification.BASIC
        });
        var name = DataModelFactory.createProperty({
            id: 'name',
            name: 'Name',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var description = DataModelFactory.createProperty({
            id: 'dsc',
            name: 'Description',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var created = DataModelFactory.createProperty({
            id: 'created',
            name: 'Created',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        });
        var lastModified = DataModelFactory.createProperty({
            id: 'lastModified',
            name: 'Last Modified',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        });
        var lastModifiedAsString = DataModelFactory.createProperty({
            id: 'lastModifiedAsString',
            name: 'Last Modified As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var createdAsString = DataModelFactory.createProperty({
            id: 'createdAsString',
            name: 'Created As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var userLastModified = DataModelFactory.createProperty({
            id: 'userLastModified',
            name: 'User Last Modified',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var actions = DataModelFactory.createProperty({
            id: 'actions',
            name: 'Actions',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var system = DataModelFactory.createProperty({
            id: 'system',
            name: 'System',
            type: PropertyType.BOOLEAN,
            classification: PropertyClassification.BASIC
        });
        var draft = DataModelFactory.createProperty({
            id: 'draft',
            name: 'Draft',
            type: PropertyType.BOOLEAN,
            classification: PropertyClassification.BASIC
        });
        var attributes = DataModelFactory.createProperty({
            id: 'attributes',
            name: 'Attributes',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var formats = DataModelFactory.createProperty({
            id: 'formats',
            name: 'Formats',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        return DataModelFactory.createEntity({
            id: IoTConstants.DEVICE_MODEL_ID,
//            entityProvider: self,
            singularName: 'Device Model',
            pluralName: 'Device Modelss',
            description: 'Business object representing a device model',
            properties: [id, name, description, created, lastModified,
                         lastModifiedAsString, userLastModified, system,
                         draft, actions, formats, attributes, createdAsString]
        });
    };

    

    IoTEntityProvider.prototype._createMessageType = function() {
        var self = this;
        var id = DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.BASIC
        });
        var name = DataModelFactory.createProperty({
            id: 'name',
            name: 'name',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        return DataModelFactory.createEntity({
            id: IoTConstants.MESSAGE_TYPE_ID,
            singularName: 'Message Type',
            pluralName: 'Message Types',
            description: 'Message Type description comes here...',
            properties: [id, name]
        });
    };
    
    // TODO: describe here additional lookups like Message Priority, Message Reliability, Message Direction, etc.
    
    
    IoTEntityProvider.prototype._createMessage = function(applicationBO, messageTypeBO, formatType) {
        var self = this;
        var id = DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.INTERNAL
        });
        // TODO: this should be modelled as lookup:
        var priority = DataModelFactory.createProperty({
            id: 'priority',
            name: 'Priority',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        // TODO: this should be modelled as lookup:
        var direction = DataModelFactory.createProperty({
            id: 'direction',
            name: 'Direction',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        var eventTime = DataModelFactory.createProperty({
            id: 'eventTime',
            name: 'Event Time',
            type: PropertyType.NUMBER,
            classification: PropertyClassification.BASIC
        });

        var props = [id, priority, direction, eventTime];

        if (formatType) {
            this.addFormatProperties(props, formatType);
        }

        var mId = formatType ? IoTUtils.getMfId(formatType) : IoTConstants.MESSAGE_ID;
        
        var messageBO = DataModelFactory.createEntity({
            id: mId,
            singularName: formatType ? formatType.name : 'Message',
            pluralName: formatType ? undefined : 'Messages',
            description: 'Message description comes here...',
            properties: props
        });
        if (formatType) {
            this.formatTypes[messageBO.getId()] = formatType;
        }

        DataModelFactory.createRelation({
            sourceEntity: messageBO,
            targetEntity: messageTypeBO,
            cardinality: RelationCardinality.MANY_TO_ONE,
            propertyId: 'type',//.getId(),
            displayNameProperty: messageTypeBO.getProperty('name')
        });

        return messageBO;
    };
    
    IoTEntityProvider.prototype._createAsset = function(applicationBO, assetType) {
        var self = this;
        var props = [];
        props.push(DataModelFactory.createProperty({
            id: 'name',
            name: 'Name',
            type: PropertyType.KEY,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'assetType',
            name: 'Type',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'dsc',
            name: 'Description',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'assignedPlace',
            name: 'Assigned Place',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'checkOutStatus',
            name: 'Check Out Status',
            type: PropertyType.BOOLEAN,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'registrationTime',
            name: 'Registration Time',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'registeredBy',
            name: 'Registered By',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastReportedTime',
            name: 'Last Reported Time',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'tags',
            name: 'Tags',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'openOutageIncidents',
            name: 'Open Outage Incidents',
            type: PropertyType.NUMBER,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastModifiedBy',
            name: 'Last Modified By',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'groupNames',
            name: 'Group Names',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'regTimeAsString',
            name: 'Registration Time As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'availabilityStatus',
            name: 'Availability Status',
            type: PropertyType.BOOLEAN,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastModifiedTimeAsString',
            name: '"Last Modified Time As String"',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastModifiedTime',
            name: 'Last Modified Time',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'utilizationStatus',
            name: 'Utilization Status',
            type: PropertyType.BOOLEAN,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'openIncidents',
            name: 'Open Incidents',
            type: PropertyType.NUMBER,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'storagePlaces',
            name: 'storagePlaces',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));

        if (assetType) {
            this.addAssetProperties(props, assetType);
        } else {
            props.push(DataModelFactory.createProperty({
                id: 'attributes',
                name: 'Attributes',
                type: PropertyType.TEXT,
                classification: PropertyClassification.BASIC
            }));
        }
        
        var aId = assetType ? IoTUtils.getAtId(assetType) : IoTConstants.ASSET_ID;
        
        var assetBO = DataModelFactory.createEntity({
            id: aId,
            singularName: assetType ? assetType.name : 'Asset',
            pluralName: assetType ? undefined : 'Assets',
            description: 'Asset description comes here...',
            properties: props
        });
        
        if (assetType) {
            this.assetTypes[assetBO.getId()] = assetType;
        }
        
        return assetBO;
    }

    IoTEntityProvider.prototype._createFence = function() {
        var self = this;
        var props = [];
        props.push(DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.INTERNAL
        }));
        props.push(DataModelFactory.createProperty({
            id: 'enabled',
            name: 'Enabled',
            type: PropertyType.BOOLEAN,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'geoJSON',
            name: 'Geo JSON',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'tags',
            name: 'Tags',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'name',
            name: 'Name',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'applicationId',
            name: 'ApplicationId',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'created',
            name: 'Created',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'createdAsString',
            name: 'Created As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastModified',
            name: 'Created As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastModifiedAsString',
            name: 'Last Modified As String',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));

        return DataModelFactory.createEntity({
            id: IoTConstants.FENCE_ID,
//                entityProvider: self,
            singularName: 'Fence',
            pluralName: 'Fences',
            description: 'Business object representing a GeoFence',
            properties: props
        });
        
    };

    IoTEntityProvider.prototype._createPlace = function() {
        var self = this;
        var id = DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.INTERNAL
        });
        var name = DataModelFactory.createProperty({
            id: 'name',
            name: 'Name',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var type = DataModelFactory.createProperty({
            id: 'type',
            name: 'type',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });
        var tags = DataModelFactory.createProperty({
            id: 'tags',
            name: 'Tags',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        var description = DataModelFactory.createProperty({
            id: 'dsc',
            name: 'Description',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        var geoFences = DataModelFactory.createProperty({
            id: 'geoFences',
            name: 'GeoFences',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        });

        return DataModelFactory.createEntity({
            id: IoTConstants.PLACE_ID,
//                entityProvider: self,
            singularName: 'Place',
            pluralName: 'Places',
            description: 'Business object representing a Place',
            properties: [id, name, type, description, tags, geoFences]
        });
        
    };

    IoTEntityProvider.prototype._createIncident = function() {
        var self = this;
        var props = [];
        props.push(DataModelFactory.createProperty({
            id: 'id',
            name: 'ID',
            type: PropertyType.KEY,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'summary',
            name: 'Summary',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'type',
            name: 'type',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'tags',
            name: 'Tags',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'dsc',
            name: 'Description',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'affectedObjects',
            name: 'Affected Objects',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'rule',
            name: 'Rule',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'createdTime',
            name: 'Created Time',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'createdBy',
            name: 'Created By',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'lastModifiedTime',
            name: 'Last Modified Time',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'incidentTime',
            name: 'Incident Time',
            type: PropertyType.DATETIME,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'comments',
            name: 'Comments',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'priority',
            name: 'Priority',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));
        props.push(DataModelFactory.createProperty({
            id: 'contextInformation',
            name: 'Context Information',
            type: PropertyType.TEXT,
            classification: PropertyClassification.BASIC
        }));

        return DataModelFactory.createEntity({
            id: IoTConstants.INCIDENT_ID,
//                entityProvider: self,
            singularName: 'Incident',
            pluralName: 'Incidents',
            description: 'Business object representing a Place',
            properties: props
        });
        
    };

    IoTEntityProvider.prototype.addFormatProperties = function(properties, format) {
        format.fields.forEach(function(oneField) {
            var newProperty = DataModelFactory.createProperty({
                id: oneField.name,
                name: oneField.name,
                type: oneField.type === 'NUMBER' ? PropertyType.NUMBER : PropertyType.TEXT, // XXX TODO: use correct property type here
                classification: PropertyClassification.BASIC
            });
            properties.push(newProperty);
        });
    }
    
    IoTEntityProvider.prototype.addAssetProperties = function(properties, assetType) {
    	assetType.attributes.forEach(function(oneAttribute) {
            var newProperty = DataModelFactory.createProperty({
                id: oneAttribute.name,
                name: oneAttribute.name,
                type: oneAttribute.type === 'NUMBER' ? PropertyType.NUMBER : PropertyType.TEXT,
                classification: PropertyClassification.BASIC
            });
            properties.push(newProperty);
        });
    }
    
    IoTEntityProvider.prototype.getEntities = function() {
        return this._entities;
    };

    IoTEntityProvider.prototype.getEntityById = function(id) {
        var res;
        this._entities.forEach(function(ent) {
            if (ent.getId() === id) {
                res = ent;
            }
        });
        return res;
    };

    IoTEntityProvider.prototype.getCustomMessageBOIds = function() {
        return Object.getOwnPropertyNames(this.formatTypes);
    };

    IoTEntityProvider.prototype.getCustomMessageFormat = function(boId) {
        return this.formatTypes[boId];
    };

    return IoTEntityProvider;
});
