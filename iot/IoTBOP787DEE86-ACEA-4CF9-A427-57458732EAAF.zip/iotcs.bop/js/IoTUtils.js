define([
    'operation/js/api/PaginationRequest',
    'com.oracle.iot.bop/js/IoTConstants'
], function (
	PaginationRequest,
    IoTConstants
   ) {

    'use strict';

    var IoTUtils = function() {
        AbcsLib.throwStaticClassError();
    };
    
    IoTUtils.cleanMfUrn = function(formatType) {
        return formatType.id.replace(new RegExp(':', 'g'), '.');
    };
    
    IoTUtils.cleanAtName = function(assetType) {
        return assetType.name.replace(new RegExp('(:| |_)', 'g'), '.');
    };

    IoTUtils.getMfId = function (formatType) {
        var res = IoTConstants.MESSAGE_ID;
        if (formatType) {
            res += '.' + IoTUtils.cleanMfUrn(formatType);
        }
        return res;
    };
    
    IoTUtils.getPaginationRequestWithDefault = function(operationData) {
    	var request = operationData.getPaginationRequest();
    	if (request) {
    		return request;
    	}
    	return PaginationRequest.createStandard({
    			offset: 0,
    			pageSize: 15
    		});
    }
    
    IoTUtils.getAtId = function (assetType) {
        var res = IoTConstants.ASSET_ID;
        if (assetType) {
            res += '.' + IoTUtils.cleanAtName(assetType);
        }
        return res;
    };
    
    IoTUtils.parseFormats = function (response) {
        var res = [];
        response.items.forEach(function(oneFormat) {
            res.push({
                id : oneFormat.urn,
                name : oneFormat.name,
                description : oneFormat.description,
                type : oneFormat.type,
                deviceModel : oneFormat.deviceModel,
                fields : oneFormat.value.fields
            });
        });
        return res;
    }
    
    IoTUtils.parseAssetTypes = function (response) {
        var res = [];
        response.items.forEach(function(oneAssetType) {
            res.push({
            	id : oneAssetType.id,
                name : oneAssetType.name,
                description : oneAssetType.description,
                attributes : oneAssetType.attributes,
                metrics : oneAssetType.metrics,
                maintenanceActivities: oneAssetType.maintenanceActivities
            });
        });
        return res;
    }

    IoTUtils.getAllMfIdsAndFormats = function () {
        var result = [];
        var rawFormats = JSON.parse(IoTConstants.IOT_FORMATS);
        IoTUtils.parseFormats(rawFormats).forEach(function(oneFormat) {
            if (oneFormat.type === 'DATA') {
                result.push({id: IoTUtils.getMfId(oneFormat), format: oneFormat});
            }
        });
        return result;
    };
    
    IoTUtils.getAllAtIdsAndTypes = function () {
        var result = [];
        var rawAssetTypes = JSON.parse(IoTConstants.IOT_ASSET_TYPES);
        IoTUtils.parseAssetTypes(rawAssetTypes).forEach(function(oneAssetType) {
        	var tmp = {id: IoTUtils.getAtId(oneAssetType), assetType: oneAssetType};
            result.push(tmp);
        });
        return result;
    };

    IoTUtils.getAllMfEntitiesAndFormats = function () {
        var eafs = [];
        IoTUtils.getAllMfIdsAndFormats().forEach(function(mfObject) {
                eafs.push({entity: Abcs.Entities().findById(mfObject.id), format: mfObject.format});
        });
        return eafs;
    };
    
    IoTUtils.getAllAtEntitiesAndTypes = function () {
        var eafs = [];
        IoTUtils.getAllAtIdsAndTypes().forEach(function(atObject) {
                eafs.push({entity: Abcs.Entities().findById(atObject.id), assetType: atObject.assetType});
        });
        return eafs;
    };

    return IoTUtils;

});
