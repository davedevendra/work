define([
    'com.oracle.iot.bop/js/IoTConstants',
    'operation/js/api/OperationResult',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'operation/js/api/PaginationCursor'
], function(
        IoTConstants,
        OperationResult,
        Resource,
        OperationBuilder,
        Operation,
        PaginationCursor
    ) {

    'use strict';

    var Application = function() {
        AbcsLib.checkSingleton(Application);
    };

    Application.prototype.getResource = function(appId) {
    	var url = IoTConstants.IOT_URL(appId);
        return Resource.create({
            id : 'iot.application',
            template: url,
            entity: IoTConstants.APPLICATION_ID
        });
    };
    
    Application.prototype.buildFetchApplications = function(appId, operationProvider) {
        var applicationEntity = Abcs.Entities().findById(IoTConstants.APPLICATION_ID);
        return new OperationBuilder({
            name: 'Fetch Applications',
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
            	var url = IoTConstants.IOT_URL(appId);
                return operationProvider.getAuthenticator().invoke({
                	// only return data from the associated app
                    url: url,
                    method: 'GET',
                    dataType: 'json',
                }).then(Application._parseResults);
            }
        }).returns(applicationEntity).build();
    }

    Application._parseResults = function (response) {
        var res = [];
        if (response && response.isSuccess()) {
        	var data = response.getData();
            res.push({
                id : data.id,
                name : data.name,
                created: data.created,
                dscrptn: data.description,
                lastModified: data.lastModified,
                createdAsString: data.createdAsString,
                lastModifiedAsString: data.lastModifiedAsString,
                type: data.type,
                metadata: JSON.stringify(data.metadata)
            });
            // only return data from the associated app
            var cursor = new PaginationCursor({
            	offset: 0,
            	count: 1,
            	hasMore: false,
            	total: 1
            });
            return OperationResult.success(res, cursor);
        } else {
            return response; // OperationResult.Failure, return original response
        }
    }

    return AbcsLib.initSingleton(Application);
});
