define([
    'com.oracle.iot.bop/js/IoTConstants',
    'com.oracle.iot.bop/js/IoTUtils',
    'operation/js/api/OperationResult',
    'operation/js/api/PaginationCursor',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'bop/js/api/operation/Pagination'
], function(
        IoTConstants,
        IoTUtils,
        OperationResult,
        PaginationCursor,
        Resource,
        OperationBuilder,
        Operation,
        Pagination
    ) {

    'use strict';

    var Message = function() {
        AbcsLib.checkSingleton(Message);
    };

    Message.prototype.getResource = function(appId, formatType) {
        if (!formatType) {
            return Resource.create({
                id : 'iot.message',
                template: IoTConstants.IOT_URL(appId) + 'messages',
                entity: IoTConstants.MESSAGE_ID
            });
        } else {
            return Resource.create({
                id : 'iot.message.' + IoTUtils.cleanMfUrn(formatType),
                template : IoTConstants.IOT_URL(appId) + 'messages',
                entity : IoTUtils.getMfId(formatType)
            });
        };
    };
    
    Message.prototype.buildFetchMessages = function(appId, operationProvider, formatType) {
        var id = IoTUtils.getMfId(formatType);
        var messageEntity = Abcs.Entities().findById(id);
        return new OperationBuilder({
            name: 'Fetch Messages',
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
                var url = IoTConstants.IOT_URL(appId)+'messages';
                if (formatType) {
                    url += "?format=" + formatType.id + '&';
                } else {
                    url += '?'
                }
                var paginationRequest = IoTUtils.getPaginationRequestWithDefault(operationData);
                var offset = paginationRequest.getOffset();
                var pageSize = paginationRequest.getPageSize();
                url += 'offset=' + offset + '&limit=' + pageSize;
                return operationProvider.getAuthenticator().invoke({
                    url: url,
                    method: 'GET',
                    dataType: 'json',
                }).then(function (response) {
                    return Message._parseResults(response, formatType, messageEntity, offset);
                });
            }
        }).paginates(Pagination.STANDARD).returns(messageEntity).build();
    }

    Message._parseResults = function (response, formatType, messageBO, offset) {
        var res = [];
        if (response && response.isSuccess()) {
        	var data = response.getData();
            data.items.forEach(function(oneMessage) {
                var record = {
                    id : oneMessage.id,
                    type : oneMessage.type,
                    source : oneMessage.source,
                    priority : oneMessage.priority,
                    direction : oneMessage.direction,
                    eventTime : oneMessage.eventTimeAsString
                };

                if (formatType && oneMessage.payload && oneMessage.payload.format ) {
                    var payload = oneMessage.payload.data;
                    Object.getOwnPropertyNames(payload).forEach(function(prop) {
                        if (messageBO.getProperty(prop)) {
                            record[prop] = payload[prop];
                        }
                    });
                    res.push(record);
                }
                if (formatType === undefined) {
                    res.push(record);
                }
            });
            var cursor = new PaginationCursor({
            	offset: offset,
            	count: data.items.length,
            	hasMore: data.hasMore
            });
            return OperationResult.success(res, cursor);
        } else {
            return response; // This will be an OperationResult.Failure, so just return the original
        }
    }

    return AbcsLib.initSingleton(Message);
});
