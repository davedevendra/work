define([
    'com.oracle.iot.bop/js/IoTConstants',
    'operation/js/api/OperationResult',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'bop/js/api/operation/Pagination',
    'operation/js/api/PaginationCursor',
    'com.oracle.iot.bop/js/IoTUtils'
], function(
        IoTConstants,
        OperationResult,
        Resource,
        OperationBuilder,
        Operation,
        Pagination,
        PaginationCursor,
        IoTUtils
    ) {

    'use strict';

    var Incident = function() {
        AbcsLib.checkSingleton(Incident);
    };

    Incident.prototype.getResource = function(appId) {
        var resource = Resource.create({
            id : 'iot.incident',
            template: IoTConstants.IOT_AM_URL(appId) + 'incidents',
            entity: IoTConstants.INCIDENT_ID
        });
        return resource;
    };

    Incident.prototype.buildFetchIncidents = function(appId, operationProvider) {
        var incidentEntity = Abcs.Entities().findById(IoTConstants.INCIDENT_ID);
        return new OperationBuilder({
            name: 'Fetch Incidents',
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
                var paginationRequest = IoTUtils.getPaginationRequestWithDefault(operationData);
                var offset = paginationRequest.getOffset();
                var pageSize = paginationRequest.getPageSize();
                return operationProvider.getAuthenticator().invoke({
                    url: IoTConstants.IOT_AM_URL(appId) + 'incidents?offset=' + offset + '&limit=' + pageSize,
                    method: 'GET',
                    dataType: 'json'
                }).then(Incident._parseResults);
            }
        }).paginates(Pagination.STANDARD).returns(incidentEntity).build();
    }

    Incident._parseResults = function (response) {
        var res = [];
        if (response.isSuccess()) {
            var data = response.getData();
            data.items.forEach(function(oneIncident) {
                res.push({
                    id : oneIncident.id,
                    type : oneIncident.type,
                    summary : oneIncident.summary,
                    state : oneIncident.state,
                    tags : JSON.stringify(oneIncident.tags),
                    affectedObjects : JSON.stringify(oneIncident.contextInformation.affectedObjects),
                    rule : oneIncident.rule,
                    lastModifiedBy : oneIncident.lastModifiedBy,
                    lastModifiedTime : oneIncident.lastModifiedTime,
                    createdTime : oneIncident.createdTime,
                    createdBy : oneIncident.createdBy,
                    incidentTime : oneIncident.incidentTime,
                    comments : JSON.stringify(oneIncident.coomments),
                    applicationId : oneIncident.applicationId,
                    contextInformation : JSON.stringify(oneIncident.contextInformation)
                });
            });
            var cursor = new PaginationCursor({
                offset: data.offset,
                count: data.items.length,
                hasMore: data.hasMore
            });
            return OperationResult.success(res, cursor);
        }
        return response; // This will be an OperationResult.Failure, so just return the original
    }

    return AbcsLib.initSingleton(Incident);
});
