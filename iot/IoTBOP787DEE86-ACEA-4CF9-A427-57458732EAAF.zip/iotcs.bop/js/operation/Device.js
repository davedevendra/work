define([
    'com.oracle.iot.bop/js/IoTConstants',
    'operation/js/api/OperationResult',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'bop/js/api/operation/Pagination',
    'operation/js/api/PaginationCursor',
    'com.oracle.iot.bop/js/IoTUtils'
], function(
        IoTConstants,
        OperationResult,
        Resource,
        OperationBuilder,
        Operation,
        Pagination,
        PaginationCursor,
        IoTUtils
    ) {

    'use strict';

    var Device = function() {
        AbcsLib.checkSingleton(Device);
    };

    Device.prototype.getResource = function(appId) {
        var resource = Resource.create({
            id : 'iot.device',
            template: IoTConstants.BASE_IOT_URL + 'apps/' + appId + '/devices',
            entity: IoTConstants.DEVICE_ID
        });
        return resource;
    };
    
    Device.prototype.buildFetchDevices = function(appId, operationProvider) {
        var deviceEntity = Abcs.Entities().findById(IoTConstants.DEVICE_ID);
        return new OperationBuilder({
            name: 'Fetch Devices',
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
                var paginationRequest = IoTUtils.getPaginationRequestWithDefault(operationData);
                var offset = paginationRequest.getOffset();
                var pageSize = paginationRequest.getPageSize();
                return operationProvider.getAuthenticator().invoke({
                    url: IoTConstants.IOT_URL(appId)+'devices?offset=' + offset + '&limit=' + pageSize,
                    method: 'GET',
                    dataType: 'json',
                    // pagination: paginationRequest,
                }).then(Device._parseResults);
            }
        }).paginates(Pagination.STANDARD).returns(deviceEntity).build();
    }

    Device._parseResults = function (response) {
        var res = [];
        if (response.isSuccess()) {
        	var data = response.getData();
            data.items.forEach(function(oneDevice) {
                res.push({
                    id : oneDevice.id,
                    name : oneDevice.name,
                    manufacturer : oneDevice.manufacturer,
                    state : oneDevice.state
                });
            });
            var cursor = new PaginationCursor({
                offset: data.offset,
                count: data.items.length,
                hasMore: data.hasMore
            });
            return OperationResult.success(res, cursor);
        } else {
            return response; // failure, so just return original response
        }
    }

    return AbcsLib.initSingleton(Device);
});
