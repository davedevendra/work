define([
    'com.oracle.iot.bop/js/IoTConstants',
    'operation/js/api/OperationResult',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'bop/js/api/operation/Pagination',
    'operation/js/api/PaginationCursor',
    'com.oracle.iot.bop/js/IoTUtils'
], function(
        IoTConstants,
        OperationResult,
        Resource,
        OperationBuilder,
        Operation,
        Pagination,
        PaginationCursor,
        IoTUtils
    ) {

    'use strict';

    var Place = function() {
        AbcsLib.checkSingleton(Place);
    };

    Place.prototype.getResource = function(appId) {
        var resource = Resource.create({
            id : 'iot.place',
            template: IoTConstants.IOT_AM_URL(appId) + 'places',
            entity: IoTConstants.PLACE_ID
        });
        return resource;
    };
    
    Place.prototype.buildFetchPlaces = function(appId, operationProvider) {
        var placeEntity = Abcs.Entities().findById(IoTConstants.PLACE_ID);
        return new OperationBuilder({
            name: 'Fetch Places',
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
                var paginationRequest = IoTUtils.getPaginationRequestWithDefault(operationData);
                var offset = paginationRequest.getOffset();
                var pageSize = paginationRequest.getPageSize();
                return operationProvider.getAuthenticator().invoke({
                    url: IoTConstants.IOT_AM_URL(appId)+'places?offset=' + offset + '&limit=' + pageSize,
                    method: 'GET',
                    dataType: 'json'
                }).then(Place._parseResults);
            }
        }).paginates(Pagination.STANDARD).returns(placeEntity).build();
    };

    Place._parseResults = function (response) {
        var res = [];
        if (response.isSuccess()) {
            var data = response.getData();
            data.items.forEach(function(onePlace) {
                res.push({
                    id : onePlace.id,
                    name : onePlace.name,
                    dsc : onePlace.description,
                    type : onePlace.type,
                    tags : JSON.stringify(onePlace.tags),
                    geoFences : JSON.stringify(onePlace.geoFences)
                });
            });
            var cursor = new PaginationCursor({
                offset: data.offset,
                count: data.items.length,
                hasMore: data.hasMore
            });
            return OperationResult.success(res, cursor);
        } else {
            return response; // failure, so just return original response
        }
    };

    return AbcsLib.initSingleton(Place);
});
