define([
    'com.oracle.iot.bop/js/IoTConstants',
    'com.oracle.iot.bop/js/IoTUtils',
    'operation/js/api/OperationResult',
    'operation/js/api/PaginationCursor',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'bop/js/api/operation/Pagination'
], function(
        IoTConstants,
        IoTUtils,
        OperationResult,
        PaginationCursor,
        Resource,
        OperationBuilder,
        Operation,
        Pagination
    ) {

    'use strict';

    var Asset = function() {
        AbcsLib.checkSingleton(Asset);
    };
    
    Asset._getAssetUrl = function(assetType) {
        if (!assetType) {
            return IoTConstants.IOT_AM_URL() + 'assets';
        }
        return IoTConstants.IOT_AM_URL() + 'search/asset-index/asset/_search';
    }

    Asset.prototype.getResource = function(appId, assetType) {
        if (!assetType) {
            return Resource.create({
                id : 'iot.asset',
                template: Asset._getAssetUrl(assetType),
                entity: IoTConstants.ASSET_ID
            });
        } else {
            return Resource.create({
                id : 'iot.asset.' + IoTUtils.getAtId(assetType),
                template : Asset._getAssetUrl(assetType),
                entity : IoTUtils.getAtId(assetType)
            });
        };
    };
    
    Asset._getAssetSearchQuery = function(offset, limit, assetType) {
        if (!assetType) {
            return undefined;
        }
        return '{"query":{"bool":{"must":{"term":{"type.raw":"' + assetType.name + '"}}}},"size":' + limit + ',"from": ' + offset + ',"aggs":{}}';
    };
    
    Asset._createCursor = function(data, offset, assetType) {
        if (!assetType) {
            return new PaginationCursor({
                offset: data.offset,
                count: data.items.length,
                hasMore: data.hasMore
            });
        } else {
            return new PaginationCursor({
                offset: offset, // use offset from original request
                count: data.hits.hits.length,
                hasMore: (data.hits.total > (data.hits.hits.length + offset))
            });
        }
    }

    
    Asset._getFetchAssetsName = function(assetType) {
      if (assetType) {
        return 'Fetch '+ assetType.name + ' Assets';
      }
      return 'Fetch Assets';
    }
    
    Asset.prototype.buildFetchAssets = function(appId, operationProvider, assetType) {
        var id = IoTUtils.getAtId(assetType);
        var assetEntity = Abcs.Entities().findById(id);
        return new OperationBuilder({
            name: Asset._getFetchAssetsName(assetType),
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
                var paginationRequest = IoTUtils.getPaginationRequestWithDefault(operationData);
                var offset = paginationRequest.getOffset();
                var pageSize = paginationRequest.getPageSize();
                if (assetType) {
                    return operationProvider.getAuthenticator().invoke({
                        url: Asset._getAssetUrl(assetType),
                        method: 'POST',
                        dataType: 'json',
                        data: Asset._getAssetSearchQuery(offset, pageSize, assetType)
                    }).then(function (response) {
                        return Asset._parseResults(response, offset, assetType, assetEntity);
                    });
                } else {
                    return operationProvider.getAuthenticator().invoke({
                        url: Asset._getAssetUrl(assetType) + '?offset=' + offset + '&limit=' + pageSize,
                        method: 'GET',
                        dataType: 'json'
                    }).then(function (response) {
                        return Asset._parseResults(response, offset, assetType, assetEntity);
                    });
                }
            }
        }).paginates(Pagination.STANDARD).returns(assetEntity).build();
    }
    
    Asset._createRecord = function(oneAsset, assetBO, assetType) {
        var record = {};
        if (!assetType) {
            record = {
                name : oneAsset.name,
                assetType : oneAsset.type,
                dsc : oneAsset.description,
                assignedPlace : (oneAsset.assignedPlace != undefined) ? oneAsset.assignedPlace.name : undefined,
                checkOutStatus : oneAsset.checkOutStatus,
                registrationTime : oneAsset.registrationTime,
                registeredBy : oneAsset.registeredBy,
                lastModifiedTime : oneAsset.lastModifiedTime,
                lastModifiedBy : oneAsset.lastModifiedBy,
                lastReportedTime : oneAsset.lastReportedTime,
                tags : JSON.stringify(oneAsset.tags),
           	    attributes : JSON.stringify(oneAsset.attributes),
                storagePlaces : JSON.stringify(oneAsset.storagePlaces),
                availabilityStatus : oneAsset.availabilityStatus,
                groupNames : JSON.stringify(oneAsset.groupNames),
                openIncidents : oneAsset.openIncidents,
                openOutageIncidents : oneAsset.openOutageIncidents,
                utilizationStatus : oneAsset.utilizationStatus
            };
        } else {
            record = {
                name : oneAsset._source.name,
                assetType : oneAsset._source.type,
                dsc : oneAsset._source.description,
                assignedPlace : oneAsset._source.assignedPlace,
                checkOutStatus : oneAsset._source.checkOutStatus,
                registrationTime : oneAsset._source.registrationTime,
                registeredBy : oneAsset._source.registeredBy,
                lastModifiedTime : oneAsset._source.lastModifiedTime,
                lastModifiedBy : oneAsset._source.lastModifiedBy,
                lastReportedTime : oneAsset._source.lastReportedTime,
                tags : JSON.stringify(oneAsset._source.tags),
                storagePlaces : JSON.stringify(oneAsset._source.storagePlaces),
                availabilityStatus : oneAsset._source.availabilityStatus,
                groupNames : JSON.stringify(oneAsset._source.groupNames),
                openIncidents : oneAsset._source.openIncidents,
                openOutageIncidents : oneAsset._source.openOutageIncidents,
                utilizationStatus : oneAsset._source.utilizationStatus
            };
        }
        if (assetType && oneAsset._source.attributes) {
            var attributes = oneAsset._source.attributes;
            Object.getOwnPropertyNames(attributes).forEach(function(attribute) {
                if (assetBO.getProperty(attribute)) {
                    record[attribute] = attributes[attribute];
                }
            });
        }
        return record;
    }
    
    Asset._parseResults = function (response, offset, assetType, assetBO) {
        var res = [];
        if (response && response.isSuccess()) {
            var data = response.getData();
            var itemList = (assetType) ? data.hits.hits : data.items;
            itemList.forEach(function(oneAsset) {
                var record = Asset._createRecord(oneAsset, assetBO, assetType)
                res.push(record);
            });
            var cursor = Asset._createCursor(data, offset, assetType);
            return OperationResult.success(res, cursor);
        } else {
            return response; // This will be an OperationResult.Failure, so just return the original
        }
    }

    return AbcsLib.initSingleton(Asset);
});
