define([
    'com.oracle.iot.bop/js/IoTConstants',
    'bop/js/api/resource/Resource',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/api/Operation',
    'bop/js/api/operation/Pagination',
    'operation/js/api/PaginationCursor'
], function(
        IoTConstants,
        Resource,
        OperationBuilder,
        Operation,
        Pagination,
        PaginationCursor
    ) {

    'use strict';

    var AssetType = function() {
        AbcsLib.checkSingleton(AssetType);
    };

    /*AssetType.prototype.getResource = function(appId) {
        return Resource.create({
            id : 'iot.assettype',
            template: IoTConstants.BASE_IOT_URL + 'apps' + appId + '/formats',
            entity: IoTConstants.FORMAT_ID
        });
    };
    
    AssetType.prototype.buildFetchFormats = function(appId, operationProvider) {
        var formatEntity = Abcs.Entities().findById(IoTConstants.FORMAT_ID);
        console.log('Formats.buildFetchFormats: formatEntity: ' + formatEntity);
        return new OperationBuilder({
            name: 'Fetch Formats',
            type: Operation.Type.READ_MANY,
            performs: function(operationData) {
                return operationProvider.getAuthenticator().invoke({
                    url: IoTConstants.IOT_URL(appId)+'formats',
                    method: 'GET',
                    dataType: 'json',
                }).then(Formats._parseResults);
            }
        }).paginates(Pagination.STANDARD).returns(formatEntity).build();
    }*/

    /* This function is public because it's used to parse the IOT_ASSET_TYPES JSON string in IoTConstants */
    AssetType.prototype.parseResults = function (response) {
        var res = [];
        response.items.forEach(function(oneAssetType) {
            res.push({
                id : oneAssetType.id,
                name : oneAssetType.name,
                description : oneAssetType.description,
                attributes : oneAssetType.attributes
            });
        });
        return res;
    }

    return AbcsLib.initSingleton(AssetType);
});
