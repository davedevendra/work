define([], function() {

    'use strict';

    var IoTConstants = function() {
        AbcsLib.throwStaticClassError();
    };

    IoTConstants.BOP_ID = 'iotcs.bop';

    IoTConstants.APPLICATION_ID = IoTConstants.BOP_ID + '.' + 'Application';

    IoTConstants.DEVICE_ID = IoTConstants.BOP_ID + '.' + 'Device';

    IoTConstants.DEVICE_MODEL_ID = IoTConstants.BOP_ID + '.' + 'Device Model';

    IoTConstants.MESSAGE_ID = IoTConstants.BOP_ID + '.' + 'Message';

    IoTConstants.MESSAGE_TYPE_ID = IoTConstants.BOP_ID + '.' + 'MessageType';

    IoTConstants.FORMAT_ID = IoTConstants.BOP_ID + '.' + 'Format';

    IoTConstants.ASSET_TYPE_ID = IoTConstants.BOP_ID + '.' + 'AssetType';

    IoTConstants.ASSET_ID = IoTConstants.BOP_ID + '.' + 'Asset';
    
    IoTConstants.PLACE_ID = IoTConstants.BOP_ID + '.' + 'Place';
    
    IoTConstants.FENCE_ID = IoTConstants.BOP_ID + '.' + 'Fence';
    
    IoTConstants.INCIDENT_ID = IoTConstants.BOP_ID + '.' + 'Incident';

    IoTConstants.BASE_IOT_URL = 'https://tcsiotstackiotjls-ocuocictrng18.uscom-central-1.oraclecloud.com/iot/api/v2/';
    
    IoTConstants.IOT_URL = function(appId) {
        return IoTConstants.BASE_IOT_URL + 'apps/'+appId+'/';
    };
    
    IoTConstants.BASE_IOT_AM_URL = 'https://tcsiotstackiotjls-ocuocictrng18.uscom-central-1.oraclecloud.com/assetMonitoring/webapi/v2/';
    
    IoTConstants.IOT_AM_URL = function(appId) {
        return IoTConstants.BASE_IOT_AM_URL;
    };
    
    IoTConstants.IOT_APPLICATION = '787DEE86-ACEA-4CF9-A427-57458732EAAF';

    IoTConstants.IOT_FORMATS = '{"items":[{  "urn" : "urn:com:ryde:IoT:TemperatureSenso:attributes",  "name" : "RydeCS_IoT",  "type" : "DATA",  "deviceModel" : "urn:com:ryde:IoT:TemperatureSenso",  "value" : {    "fields" : [ {      "name" : "message",      "optional" : false,      "type" : "STRING"    } ]  },  "sourceId" : "urn:com:ryde:IoT:TemperatureSenso",  "sourceType" : "DEVICE_MODEL"}]}';

    IoTConstants.IOT_ASSET_TYPES = '{"items": []}';
    
    IoTConstants._IOT_AM_ENABLED = false
    
    return IoTConstants;

});
