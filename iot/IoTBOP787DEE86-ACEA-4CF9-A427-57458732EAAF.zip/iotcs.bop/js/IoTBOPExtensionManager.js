define([
    'bop.dt/js/api/SimpleBOPExtensionManager',
    'com.oracle.iot.bop/js/IoTUtils'
], function (
        SimpleBOPExtensionManager,
        IoTUtils
    ) {

    'use strict';

    var IoTBOP = function () {
    };

    IoTBOP.prototype.getEntityProviderPath = function () {
        return 'com.oracle.iot.bop/js/IoTEntityProvider';
    };

    IoTBOP.prototype.getOperationProviderPath = function () {
        return 'com.oracle.iot.bop/js/IoTOperationProvider';
    };

    var bop = new IoTBOP();
    var mgr = new SimpleBOPExtensionManager(bop);

    return mgr;
});
