define([
    'bop/js/api/operation/BOPAuthenticators',
    'bop/js/spi/operation/OperationProvider',
    'data/js/api/lookup/LookupItem',
    'data/js/api/lookup/LookupRegistry',
    'com.oracle.iot.bop/js/IoTUtils',
    'com.oracle.iot.bop/js/IoTConstants',
    'com.oracle.iot.bop/js/operation/Application',
    'com.oracle.iot.bop/js/operation/Asset',
    'com.oracle.iot.bop/js/operation/Message',
    'com.oracle.iot.bop/js/operation/Device',
    'com.oracle.iot.bop/js/operation/DeviceModel',
    'com.oracle.iot.bop/js/operation/Fence',
    'com.oracle.iot.bop/js/operation/Place',
    'com.oracle.iot.bop/js/operation/Incident',
    'data/js/api/OperationFactory',
    'data/js/api/OperationInput',
    'data/js/api/OperationOutput',
    'operation/js/api/Operation',
    'operation/js/api/OperationResult',
    'bop/js/api/operation/OperationBuilder',
    'operation/js/query/QueryParameterDescription',
    'operation/js/query/QueryDescription',
    'bop/js/api/operation/Pagination'
], function (
        BOPAuthenticators,
        OperationProvider,
        LookupItem,
        LookupRegistry,
        IoTUtils,
        IoTConstants,
        Application,
        Asset,
        Message,
        Device,
        DeviceModel,
        Fence,
        Place,
        Incident,
        OperationFactory,
        OperationInput,
        OperationOutput,
        Operation,
        OperationResult,
        OperationBuilder,
        QueryParameterDescription,
        QueryDescription,
        Pagination
    ) {

    'use strict';

    var IoTOperationProvider = function(dependencies) {

        var self = this;
        self._dependencies = dependencies;
        self._resources = [];
        self._init();
    };

    IoTOperationProvider._LOGGER = Logger.get('IoT/IoTOperationProvider');

    IoTOperationProvider.prototype.getAuthenticator = function() {
        var self = this;
        return BOPAuthenticators.getDefault(this._dependencies, {
            getResources : function() {
                return self._resources;
            }
        });
    };

    IoTOperationProvider.prototype._init = function() {
        var self = this;

        self._operations = [];

        self._initForApplication();
        self._initForMessageType();
        var messageEntity = Abcs.Entities().findById(IoTConstants.MESSAGE_ID);
        self._initForMessage(messageEntity);
        self._initForDevice();
        self._initForDeviceModel();
        IoTUtils.getAllMfEntitiesAndFormats().forEach(function(messageInfo) {
            self._initForMessage(messageInfo.entity, messageInfo.format);
        });
        if (IoTConstants._IOT_AM_ENABLED) {
            var assetEntity = Abcs.Entities().findById(IoTConstants.ASSET_ID);
            self._initForAsset(assetEntity);
            IoTUtils.getAllAtEntitiesAndTypes().forEach(function(assetInfo) {
              var keys = [];
              for(var k in assetInfo) keys.push(k);
              self._initForAsset(assetInfo.entity, assetInfo.assetType);
             });
            self._initForFence(Abcs.Entities().findById(IoTConstants.FENCE_ID));
            self._initForPlace(Abcs.Entities().findById(IoTConstants.PLACE_ID));
            self._initForIncident(Abcs.Entities().findById(IoTConstants.INCIDENT_ID));

        }
    };

    IoTOperationProvider.prototype._initForApplication = function() {
        var self = this;
        var entities = Abcs.Entities();
        var applicationEntity = entities.findById(IoTConstants.APPLICATION_ID);
        if (applicationEntity) {
            self._resources.push(Application.getResource(IoTConstants.IOT_APPLICATION));
            var findApplications = Application.buildFetchApplications(IoTConstants.IOT_APPLICATION, self);
            self._register(findApplications);
        }
    };

    IoTOperationProvider.prototype._register = function(op) {
        this._operations.push(op);
    };
    
    IoTOperationProvider.prototype._initForDevice = function() {
        var self = this;
        var deviceEntity = Abcs.Entities().findById(IoTConstants.DEVICE_ID);
        if (deviceEntity) {
            self._resources.push(Device.getResource(IoTConstants.IOT_APPLICATION));
            var findDevices = Device.buildFetchDevices(IoTConstants.IOT_APPLICATION, self);
            self._register(findDevices);
        }
    };

    IoTOperationProvider.prototype._initForDeviceModel = function() {
        var self = this;
        var deviceModelEntity = Abcs.Entities().findById(IoTConstants.DEVICE_MODEL_ID);
        if (deviceModelEntity) {
            self._resources.push(DeviceModel.getResource(IoTConstants.IOT_APPLICATION));
            var findDeviceModels = DeviceModel.buildFetchDeviceModels(IoTConstants.IOT_APPLICATION, self);
            self._register(findDeviceModels);
        }
    };

    IoTOperationProvider.prototype._initForMessageType = function() {
        var self = this;
        var messageTypeEntity = Abcs.Entities().findById(IoTConstants.MESSAGE_TYPE_ID);
        if (messageTypeEntity) {
            var returnTypes = new OperationBuilder({
                name: 'Return Types',
                type: Operation.Type.READ_MANY,
                performs: function (operationInputData) {
                    return Promise.resolve(OperationResult.success([
                        {id: 'DATA', name: 'Data'},
                        {id: 'ALERT', name: 'Alert'},
                        {id: 'REQUEST', name: 'Request'},
                        {id: 'RESPONSE', name: 'Response'},
                        {id: 'UPDATE_BUNDLE', name: 'Update Bundle'},
                        {id: 'UPDATE_BUNDLE_STATE', name: 'Update Bundle State'},
                        {id: 'WAKEUP', name: 'Wakeup'},
                        {id: 'RESOURCES_REPORT', name: 'Resources Report'}
                        ]));}
            }).returns(messageTypeEntity).build();

            self._register(returnTypes);
        }
    };

    IoTOperationProvider.prototype._initForMessage = function(messageEntity, formatType) {
        var self = this;
        if (messageEntity) {
        	var resource = Message.getResource(IoTConstants.IOT_APPLICATION, formatType);
            self._resources.push(resource);
            var findMessages = Message.buildFetchMessages(IoTConstants.IOT_APPLICATION, self, formatType);
            self._register(findMessages);
        }
    };
    
    IoTOperationProvider.prototype._initForAsset = function(assetEntity, assetType) {
        var self = this;
        if (assetEntity) {
        	var resource = Asset.getResource(IoTConstants.IOT_APPLICATION, assetType)
            self._resources.push(resource);
            var findAssets = Asset.buildFetchAssets(IoTConstants.IOT_APPLICATION, self, assetType);
            self._register(findAssets);
        }
    };
    
    IoTOperationProvider.prototype._initForFence = function() {
        var self = this;
        var fenceEntity = Abcs.Entities().findById(IoTConstants.FENCE_ID);
        if (fenceEntity) {
            self._resources.push(Fence.getResource(IoTConstants.IOT_APPLICATION));
            var findFences = Fence.buildFetchFences(IoTConstants.IOT_APPLICATION, self);
            self._register(findFences);
        }
    };
    
    IoTOperationProvider.prototype._initForPlace = function() {
        var self = this;
        var placeEntity = Abcs.Entities().findById(IoTConstants.PLACE_ID);
        if (placeEntity) {
            self._resources.push(Place.getResource(IoTConstants.IOT_APPLICATION));
            var findPlaces = Place.buildFetchPlaces(IoTConstants.IOT_APPLICATION, self);
            self._register(findPlaces);
        }
    };
    
    IoTOperationProvider.prototype._initForIncident = function() {
        var self = this;
        var incidentEntity = Abcs.Entities().findById(IoTConstants.INCIDENT_ID);
        if (incidentEntity) {
            self._resources.push(Incident.getResource(IoTConstants.IOT_APPLICATION));
            var findIncidents = Incident.buildFetchIncidents(IoTConstants.IOT_APPLICATION, self);
            self._register(findIncidents);
        }
    };

    IoTOperationProvider.prototype.getOperations = function() {
        return this._operations;
    };

    return IoTOperationProvider;

});
