// validate item for copy
// 10/12/2017 v3.0

resultStr = "";
isValid = false;

print _system_selected_document_number;
if(len(isItemSelected_line) <= 0) {
	resultStr = "Please select the item first and click the 'Select Valve Item' button.-"+isItemSelected_line+"-"+selectedValveItem_quote;
	//return resultStr;
}
if(len(isItemSelected_line) > 0 ) {
	for line in line_fcoProcess {
		if(line._document_number == isItemSelected_line) {
			if(line.alt_line == "A") {
				isValid = true;
				resultStr = "Alternate Item cannot be copied.-"+isItemSelected_line+"-"+selectedValveItem_quote;
			}
		} 
	}
}
return resultStr;