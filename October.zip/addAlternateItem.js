// addAlternateItems
// ddevendra
// 10/10/2017 v3.0

resultStr = "";
resultStr = resultStr + commerce.mapConfigValues();
//resultStr = resultStr + commerce.sequenceLineItems();

//first find docnumbers which are copied 

altValue = "A";
primaryItemParentLineNumSeq = "";
primaryItemParentDocNum = "";
copiedParentValveItemDocNum = "";
altDocNumberArr = string[];


docnumToSeqNumMap = dict("string");  // docnum => line# value


print selectedValveItem_quote;

for line in line_fcoProcess {
	currenLineDocNum = line._document_number;
	parentLineDocNum = line.parentLineNumber_line;
	itemType = line.itemType_line;
	put(docnumToSeqNumMap, currenLineDocNum, line.lineNumber_line);
	//if(selectedValveItem_quote <> "") {
		//print line._original_document_number;
		if(itemType == "V" AND line._original_document_number <> "-1" AND line.isCopiedItem_line == "N")  {
			copiedParentValveItemDocNum = line._document_number;
			//primaryItemParentDocNum = line._original_document_number;
		}	
		if(itemType == "RA" AND line._original_document_number <> "-1" AND line.isCopiedItem_line == "N") {
			resultStr = resultStr + currenLineDocNum + "~parentLineNumber_line~" +copiedParentValveItemDocNum +"|";
			//primaryItemParentDocNum = line._original_document_number;
		} 
		if(line._original_document_number <> "-1" AND line.isCopiedItem_line == "N") {
			append(altDocNumberArr, line._document_number);
		} 
	//}
}



/*for altDocNumberItem in altDocNumberArr {
	resultStr = resultStr + altDocNumberItem + "~alt_line~" +altValue +"|";
}*/

print altDocNumberArr;
print docnumToSeqNumMap;

for line in  line_fcoProcess {
	currenLineDocNum = line._document_number;
	parentLineDocNum = line.parentLineNumber_line;
	itemType = line.itemType_line;
	// if(primaryItemParentDocNum == currenLineDocNum) {
	// 	primaryItemParentLineNumSeq = line.lineNumber_line;
	// }
	ind = findinarray(altDocNumberArr, currenLineDocNum);

	if(ind <> -1) {
		resultStr = resultStr + currenLineDocNum + "~alt_line~" +altValue +"|";
		if(itemType == "V" AND line._original_document_number <> "-1") {
			primaryItemParentLineNumSeq = get(docnumToSeqNumMap, line._original_document_number);
			//resultStr = resultStr + currenLineDocNum + "~parentLineNumber_line~"+line._original_document_number+"|";
			resultStr = resultStr + currenLineDocNum + "~parentLineNumber_line~"+"-1"+"|";
			resultStr = resultStr + currenLineDocNum + "~lineNumber_line~"+primaryItemParentLineNumSeq+"(A)"+"|";
			copiedParentValveItemDocNum = line._document_number;
			//copiedParentValveItemDocNum = line._original_document_number;
		}
		if(itemType == "A" AND line._original_document_number <> "-1") {
			primaryItemParentLineNumSeq = get(docnumToSeqNumMap, line._original_document_number);
			resultStr = resultStr + currenLineDocNum + "~parentLineNumber_line~"+"-"+"|";
			resultStr = resultStr + currenLineDocNum + "~lineNumber_line~"+primaryItemParentLineNumSeq+"(A)"+"|";

		}
		if(itemType == "RA" AND line._original_document_number <> "-1") {
			primaryItemParentLineNumSeq = get(docnumToSeqNumMap, line._original_document_number);
			resultStr = resultStr + currenLineDocNum + "~parentLineNumber_line~"+copiedParentValveItemDocNum+"|";
			resultStr = resultStr + currenLineDocNum + "~lineNumber_line~"+primaryItemParentLineNumSeq+"(A)"+"|";
		}
		if(itemType == "SP" AND line._original_document_number <> "-1") {
			primaryItemParentLineNumSeq = get(docnumToSeqNumMap, line._original_document_number);
			resultStr = resultStr + currenLineDocNum + "~lineNumber_line~"+primaryItemParentLineNumSeq+"(A)"+"|";	
		}
		resultStr = resultStr + currenLineDocNum + "~alt_line~"+"A" +"|";
	}

	
}

return resultStr;