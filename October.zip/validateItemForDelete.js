// validate item for delete
// 10/12/2017 v1.0

resultStr = "";
isValid = false;

print _system_selected_document_number;
if(len(selectedValveItem_quote) <= 0) {
	resultStr = "Please select the item first and click the 'Select Valve Item' button.-"+isItemSelected_line+"-"+selectedValveItem_quote;
	//return resultStr;
}
if(len(selectedValveItem_quote) > 0 ) {
	for line in line_fcoProcess {
		if(line._document_number == selectedValveItem_quote) {
			if(line.itemType_line == "V") {
				if(line.totalChildSubModelCount_line > 0) {
					//there are related actuator associated.
					resultStr = "Cannot Delete the package item. Please select the related actuator items also.-"+isItemSelected_line+"-"+selectedValveItem_quote;
				}	
				
			}
		} 
	}
}
return resultStr;