// collapse the spareparts always when loaded in the page.

resultStr = "<script>\n";
isSpanCollapsedAdded = false;
for line in line_fcoProcess {
	currentLineDoc=line._document_number;
	parentLineDocNumber = line.parentLineNumber_line;
	itemType = line.itemType_line;

	
	//if(parentLineDocNumber == "-1" AND parentLineDocNumber <> "-" AND parentLineDocNumber <> "") { // parent item
	if(itemType == "V" OR itemType == "A" OR itemType == "RA") {

		totalCountChildSpareParts=line.totalCountChildSpareParts_line;

		childSparePartsDocumentNumbers=line.childSparePartsDocumentNumbers_line;
    		childSparePartsDocumentNumbersArr = split(childSparePartsDocumentNumbers, "#S#");
    		print childSparePartsDocumentNumbersArr;

	    	if(totalCountChildSpareParts > 0  AND isSpanCollapsedAdded == false) {
	    		resultStr = resultStr + "\tif($(\"span[class='collapsible']\")) {\n";
	    			resultStr = resultStr + "\t\t$(\"span[class='collapsible']\").addClass('collapsed');";	
	    		resultStr = resultStr + "\t}";
	    		isSpanCollapsedAdded = true;
	    	}
	
	    	for childSparePartsDocumentItem in childSparePartsDocumentNumbersArr {
	    		resultStr = resultStr + "\tif($(\"tr[documentnumber='"+childSparePartsDocumentItem+"']\")) {\n";
	    			resultStr = resultStr + "\t\t$(\"tr[documentnumber='"+childSparePartsDocumentItem+"']\").addClass(\"line-item-collapsed\");\n";
	    		resultStr = resultStr + "\t}\n";
	    		
	    	}    	
	
	}
	
	// color items which are selected
	if(selectedValveItem_quote <> "" AND len(selectedValveItem_quote) >= 0) {
		if(currentLineDoc == selectedValveItem_quote OR parentLineDocNumber == selectedValveItem_quote) {
			resultStr = resultStr + "\t$(\"tr[documentnumber='"+currentLineDoc+"']\").css(\"background-color\", \"lightyellow\");\n";
		}
	} 	
	
}

resultStr = resultStr + "</script>\n";
print resultStr;
return resultStr;