// copySelectedItem - After Formula Modify
// ddevendra 
// 10/03/2017 v1.0

resultStr = "";
resultStr = resultStr + commerce.mapConfigValues();
//resultStr = resultStr + commerce.sequenceLineItems();

//first find out the copied Parent Valve Item document number

copiedParentValveItemDocNum = "";
for line in line_fcoProcess {
	currenLineDocNum = line._document_number;
	parentLineDocNum = line.parentLineNumber_line;
	itemType = line.itemType_line;
	
	if(itemType == "V" AND line._original_document_number <> "-1") {
		copiedParentValveItemDocNum = line._document_number;
	}
	if(itemType == "RA" AND line._original_document_number <> "-1") {
		resultStr = resultStr + currenLineDocNum + "~parentLineNumber_line~" +copiedParentValveItemDocNum +"|"; 
	}
}

return resultStr;